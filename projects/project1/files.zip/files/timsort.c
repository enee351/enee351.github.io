#include <inttypes.h>
#define SORT_NAME int32
#define SORT_TYPE int32_t

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include "timsort.h"

//The first argument is the name of the file that contains the values to
//be sorted. The second is the number of elements in that file that will
//be sorted. The third argument is the file in which the program will
//print the results
int main( int argc, char *argv[] )  {
	long int i, d, t;
	
	FILE *unsortedFile = fopen(argv[1], "r");
	FILE *sortedFile = fopen(argv[3], "w");
	
	char *numelts = argv[2];
	char *end;
	int32_t count = strtol(numelts, &end, 10);		
	int32_t *nums=(int32_t*)malloc(count*sizeof(int32_t));
	
	for (i = 0; i < count; i++) {
        fscanf(unsortedFile, "%d\n", &nums[i]);
    }
    
    int32_tim_sort(nums, count);
		
    for (i = 0; i < count; i++) {
        fprintf(sortedFile, "%d\n", nums[i]);
    }     
	
	free(nums);
	fclose(unsortedFile);
	fclose(sortedFile);
    return 0;
}
