
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <math.h>

//this is a program to generate a random graph. 

int main(int argc, char *argv[]) {
	/* Code to print the edges of the graph to a file*/
	int i;
	srand(time(NULL));
	FILE *undirectedEdges = fopen(argv[1], "w"); //open a file pointer to the file containing the undirected edges that will compose our graph
	char *num_vertices = argv[2];
	char *num_edges = argv[3];
	char *end;
	int vcount = strtol(num_vertices, &end, 10);
	int ecount = strtol(num_edges, &end, 10);
	printf("verifying %d vertices and %d edges\n", vcount, ecount);
	
	int v1 = rand() % vcount;
	int v2 = rand() % vcount;
	int original = v1;
	for (i = 1; i < ecount; i++) {
		fprintf(undirectedEdges, "%d %d\n", v1, v2);
		v1 = v2;
		while (v1 == v2) {
			v2 = rand() % vcount;
		}
    }
    if(v1 != original)
		fprintf(undirectedEdges, "%d %d\n", v1, original);   //add an edge from the tail to the head unless they are the same.
	fclose(undirectedEdges);
}
