

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <math.h>


typedef struct {
   int n; //the number of rows in our adjacency matrix (should equal m)
   int m; //the number of columns in our adjacency matrix (should  equal n)
   int **values; //the values in our adjacency matrix
} Matrix;

typedef struct {
    Matrix *adj; //the adjacency matrix containing edge information for the graph
    int n; //the number of vertices currently in the graph
    int e; //the number of edges currently in the graph
} Graph;


//this function initializes a matrix of a specified size and returns a pointer to the matrix that was created
Matrix *init_matrix(int n, int m){
	Matrix *A = (Matrix*)malloc(sizeof(Matrix));
	A->n = n;
	A->m = m;
	A->values = (int**)malloc(n*sizeof(int*));
	for(int i=0; i< n; i++){
		(A->values)[i] = (int*)malloc(m*sizeof(int));
	}
	return A;
}

//this function destroys a matrix
void destroy_matrix(Matrix *A){
	int n = A->n;
	for(int i=0; i< n; i++){
		free((A->values)[i]);
	}
	free(A->values);
	free(A);
}

//this function prints a matrix
void print_matrix(Matrix *A){
	int n = A->n, m = A->m, i, j;
	int ** vals = A->values;
	for(i = 0; i < n; i++) {
		for(j = 0; j < m; j++){
			printf("%d ", vals[i][j]);		
		}
		printf("\n");		
	}
	printf("\n");		
}

//this function should contract g until it only has t vertices remaining
Graph *contract(Graph *g, int t); 

//this function checks the number of vertices in the graph, and if there
//is less than 6 it calls contract(g, 2). Otherwise, it should create
//two copies of the graph g, and then call contract(copy1_of_g, t) and
//contract(copy1_of_g, t) where t is specified in the analysis part of the
//project. it then recursively calls KSmincut on both of the contracted
//copies and returns the graph that contains the more minimum cut
int KSmincut(Graph *g);


//this function determines the number of times that contract should be run.
//it then calls contract on a copy of the graph that it is given
//i.e., don't call contract on your original graph because then you won't
//be able to call contract on it again
//the number of times that you should run it is derived in the analysis
//section of the project.
//the return value of the function should be the number of edges in the 
//minimum cut found amongst all iterations of contract
int KSrunner(Graph *g);


/*
* This main function does the same things as the main function in karger.c
* Please see that file for a synopsis on calling this function
*
*/
int main(int argc, char *argv[]) {
	/* Code to test Karger Stein algorithm. */
	int i, j;
	FILE *undirectedEdges = fopen(argv[1], "r"); //open a file pointer to the file containing the undirected edges that will compose our graph
	int number_of_vertices = 100; //arbitrarily deciding that the max number of vertices will be 100
	
	Graph *g = (Graph*)malloc(sizeof(Graph)); //create our original graph
	g->adj = init_matrix(number_of_vertices, number_of_vertices); //initialize the matrix the graph contains
	
	int nodes[number_of_vertices]; //use this to determine the number of unique vertices in the graph
	
	int vert1 = -1, vert2 = -1;
	while (fscanf(undirectedEdges, "%d %d\n", &vert1, &vert2) != -1) {
        nodes[vert1] = 1; //dont care about incrementing; just care that we saw this vertix ID 
        nodes[vert2] = 1;
        g->adj->values[vert1][vert2] = 1; //set both combinations since the graph is undirected!!
        g->adj->values[vert2][vert1] = 1; //set both combinations since the graph is undirected!!
    }
    
    print_matrix(g->adj);
    
    int num_unique_vertices = 0; //since the edges are randomly generated, we may not actually have every possible vertex, hence we count them here.
    for (i=0; i < number_of_vertices; i++) {
		if(nodes[i])
			num_unique_vertices++;
	}
    
    int num_edges = 0;
    //now lets count the number of edges in our graph
    for (i=0; i < number_of_vertices; i++) {
		for (j=0; j < number_of_vertices; j++) {
			if(g->adj->values[i][j])
				num_edges++;
		}
	}
	num_edges = num_edges / 2; //since we are going to double count each edge
	printf("this graph has %d vertices and %d edges\n", num_unique_vertices, num_edges);
	
	g->n = num_unique_vertices;
	g->e = num_edges;
    
    //int mymincut = KSrunner(g)
    //printf("I claim that my graph has a min cut of %d!\n", mymincut);

	destroy_matrix(g->adj);
	free(g);
	
	fclose(undirectedEdges);
	return 0;
}
