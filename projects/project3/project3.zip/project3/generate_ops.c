
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <math.h>

//this is a program to generate random hash operations

int main(int argc, char *argv[]) {
	/* Code to print the edges of the graph to a file*/
	int i;
	srand(time(NULL));
	FILE *undirectedEdges = fopen(argv[1], "w"); 
	char *num_ops = argv[2];
	char *end;
	int count = strtol(num_ops, &end, 10);
	printf("verifying %d operations\n", count);
	
	int val, op;
	
	for (i = 1; i <= 100; i++) {
		val = rand() % 100;
		op = 1;
		
		fprintf(undirectedEdges, "%d %d\n", val, op);
    }
	
	
	for (i = 1; i <= count; i++) {
		val = rand() % 100;
		op = rand() % 3;
		
		fprintf(undirectedEdges, "%d %d\n", val, op);

    }
    
	fclose(undirectedEdges);
}
