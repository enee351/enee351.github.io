
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <math.h>



//feel free to change any of the headers, or parameter types of any of this code.
int query(int value);
void delete(int value);
void insert(int value);

int query(int value){
	printf("querying %d\n", value);
	return 0;
}

void delete(int value){
	printf("deleting %d\n", value);

}

void insert(int value){
	printf("inserting %d\n", value);

}

int hashfunction(int key, int tablesize){
  int c2=0x27d4eb2b; // random large prime number
  key = (key ^ 61) ^ (((unsigned) key) >> 16); //casting to force zero fill right shift
  key = key + (key << 3);
  key = key ^ (((unsigned) key) >> 4);
  key = key * c2;
  key = key ^ (((unsigned) key) >> 15);
  return key % tablesize;
}

int secondaryhashfunction(int key, int tablesize){
	return (key * 13) % tablesize;
}


int main(int argc, char *argv[]) {
	/* Code to parse hash file */
	int i, j;
	
	
	FILE *hashOps = fopen(argv[1], "r"); //open a file pointer to the file containing operations to perform on our hash
	FILE *output = fopen("contents.output", "w"); 	// will contain the contents of the hash table upon completion.
	FILE *accessesout = fopen("accesses.output", "w"); // will contain the number of times each bin of load factors was accessesed.
	FILE *avgsout = fopen("averages.output", "w");  // will contain the average number of cache misses for each load factor bin.
	FILE *collisionsout = fopen("collisions.output", "w"); // will contain the number of collisions that were experienced during execution.

	int value, op;
	while (fscanf(hashOps, "%d %d\n", &value, &op) != -1) {
        switch(op) {
			case 0:
				delete(value);
				break;
			case 1:
				insert(value);
				break;
			case 2:
				query(value);
				break;
			default:
				printf("There was a parse error\n");
			
		}
    }
    
	
	fclose(hashOps);
	fclose(output);
	fclose(accessesout);
	fclose(avgsout);
	fclose(collisionsout);
	
	fflush(stderr);
	 
	
	 
	return 0;
}
