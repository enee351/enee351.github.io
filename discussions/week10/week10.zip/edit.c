// A Naive recursive C++ program to find minimum number
// operations to convert str1 to str2
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

// Utility function to find minimum of three numbers
int min3(int x, int y, int z)
{
    return min(min(x, y), z);
}

int min(int x, int y)
{
    return (x>y)? y:x ;
}

int editDist(char str1[] , char str2[] , int m ,int n)
{

}

// Driver program
int main()
{
	// your code goes here
	char str1[] = "sunday";
	char str2[] = "saturday";

	printf("%d", editDist( str1 , str2 , strlen(str1), strlen(str2)));

	return 0;
}
